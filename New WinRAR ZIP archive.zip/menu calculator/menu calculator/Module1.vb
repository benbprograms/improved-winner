﻿Imports System.Math
Module Module1
    Public op, ans, num1, num2 As Integer
    Public ReadOnly VERSION As String = "0.0.1"

    Sub MenuP2()
        Console.WriteLine("#########################################")
        Console.WriteLine("#    9)  absloute                       #")
        Console.WriteLine("#    10) round up                       #")
        Console.WriteLine("#    11) round down                     #")
        Console.WriteLine("#    12) logarithm                      #")
        Console.WriteLine("#    13) sine                           #")
        Console.WriteLine("#    14) tangent                        #")
        Console.WriteLine("#    15) next                           #")
        Console.WriteLine("#    16) exit                           #")
        Console.WriteLine("#########################################")
        Try
            op = Console.ReadLine
            If op > 19 Then

                MsgBox("the number you entered is too high. Please enter 9-16!", MsgBoxStyle.Critical, "error")
                Console.Clear()

            End If
        Catch ex As Exception
            MsgBox("error. do not enter a letter!", MsgBoxStyle.Critical, "error")
            Console.Clear()

        End Try
    End Sub
    Sub Main()

        Call MenuP1()
        Select Case op
            Case 9
                Console.Write("enter the number: ")
                num1 = Console.ReadLine
                ans = Abs(num1)
                Console.Write("the absolute value of " & num1 & " is " & ans)
                Console.ReadKey()
            Case 10

            Case 11

            Case 12

            Case 13

            Case 14

            Case 15

            Case 16

            Case 17

            Case 18


            Case Else

        End Select

    End Sub
    Sub MenuP1()
        Console.WriteLine("#########################################")
        Console.WriteLine("#    1) add                             #")
        Console.WriteLine("#    2) subtract                        #")
        Console.WriteLine("#    3) multiply                        #")
        Console.WriteLine("#    4) divide                          #")
        Console.WriteLine("#    5) power                           #")
        Console.WriteLine("#    6) square                          #")
        Console.WriteLine("#    7) square root                     #")
        Console.WriteLine("#    8) next                            #")
        Console.WriteLine("#########################################")
        Try
            op = Console.ReadLine
            If op > 8 Then

                MsgBox("the number you entered is too high. Please enter 1-8!", MsgBoxStyle.Critical, "error")
                Console.Clear()
            End If
        Catch ex As Exception
            MsgBox("error. do not enter a letter!", MsgBoxStyle.Critical, "error")
            Console.Clear()

        End Try
        Select Case op
            Case 1
                Console.Clear()
                Console.Write("enter first number: ")
                num1 = Console.ReadLine
                Console.Write("enter second number: ")
                num2 = Console.ReadLine
                ans = num1 + num2
                Console.Write(num1 & " + " & num2 & " = " & ans)
                Console.ReadKey()
            Case 2
                Console.Clear()
                Console.Write("enter first number: ")
                num1 = Console.ReadLine
                Console.Write("enter second number: ")
                num2 = Console.ReadLine
                ans = num1 - num2
                Console.Write(num1 & " - " & num2 & " = " & ans)
                Console.ReadKey()
            Case 3
                Console.Clear()
                Console.Write("enter first number: ")
                num1 = Console.ReadLine
                Console.Write("enter second number: ")
                num2 = Console.ReadLine
                ans = num1 * num2
                Console.Write(num1 & " * " & num2 & " = " & ans)
                Console.ReadKey()
            Case 4
                Console.Clear()
                Console.Write("enter first number: ")
                num1 = Console.ReadLine
                Console.Write("enter second number: ")
                num2 = Console.ReadLine
                ans = num1 / num2
                Console.Write(num1 & " / " & num2 & " = " & ans)
                Console.ReadKey()
            Case 5
                Console.Clear()
                Console.Write("enter the number:")
                num1 = Console.ReadLine
                Console.Write("enter the power: ")
                num2 = Console.ReadLine
                ans = Pow(num1, num2)
                Console.Write(num1 & " to the power of " & num2 & " = " & ans)
                Console.ReadKey()
            Case 6
                Console.Clear()
                Console.Write("enter number: ")
                num1 = Console.ReadLine
                ans = Pow(num1, 2)
                Console.WriteLine(num1 & " squared is " & ans)
                Console.ReadKey()
            Case 7
                Console.Clear()
                Console.Write("enter number: ")
                num1 = Console.ReadLine
                ans = Sqrt(num1)
                Console.Write("square root of " & num1 & " = " & ans)
                Console.ReadKey()
            Case 8
                Console.Clear()
                Call MenuP2()
        End Select
    End Sub
End Module
