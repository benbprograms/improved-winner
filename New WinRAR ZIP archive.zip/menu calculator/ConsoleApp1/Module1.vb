﻿Module Module1
    Interface ben

    End Interface
    Sub Main()

    End Sub

End Module
